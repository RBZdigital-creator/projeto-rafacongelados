export type PortionSize = '500g' | '1kg';

export interface MenuItem {
  id: string;
  name: string;
  category: 'tortas' | 'massas' | 'quibe';
  categoryLabel: string;
  shortDescription: string;
  price500g: number;
  price1kg: number;
  notes?: string;
  isOnlyFrozen?: boolean;
  isOnlyOrder?: boolean;
  noBoilRequired?: boolean;
  image: string;
}

export interface CartItem {
  item: MenuItem;
  portion: PortionSize;
  quantity: number;
}
