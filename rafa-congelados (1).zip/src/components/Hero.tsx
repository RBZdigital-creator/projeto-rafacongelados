import { MessageCircle, Utensils, Instagram, Sparkles, ChefHat } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menu';

export const Hero: React.FC = () => {
  const whatsappUrl = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
    'Olá! Vim pelo site da RaFa Congelados e gostaria de fazer meu pedido.'
  )}`;

  return (
    <section className="relative bg-[#A1E4FB] pt-10 pb-16 md:pt-16 md:pb-24 overflow-hidden border-b-4 border-[#B07C54]">
      {/* Background Decorative Polka / Bubbles */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-white blur-xl" />
        <div className="absolute bottom-10 right-10 w-72 h-72 rounded-full bg-[#B07C54] blur-3xl opacity-20" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Big Brand Identity, Headline & Flyer Pills */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Scalloped Brand Seal */}
            <div className="inline-flex items-center gap-3 bg-[#FDE8D4] border-2 border-[#B07C54] px-4 py-1.5 rounded-full shadow-sm">
              <img
                src="/assets/logo_rafa.png"
                alt="Logo RaFa"
                className="w-7 h-7 object-contain"
              />
              <span className="font-display text-xs font-bold uppercase tracking-wider text-[#381F10]">
                Cardápio Oficial de Congelados Artesanais
              </span>
            </div>

            {/* Main Headline styled with flyer letters */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-[#381F10] tracking-tight uppercase font-display leading-[1.08]">
              Tortas, Massas <br />
              <span className="text-white drop-shadow-sm bg-[#B07C54] px-3 py-0.5 rounded-xl inline-block mt-1">
                &amp; Quibe de Forno
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#381F10]/90 font-medium max-w-xl leading-relaxed">
              Receitas de família com recheios generosos em porções de <strong>500g</strong> e <strong>1kg</strong>. Prontos para aquecer e transformar o almoço ou jantar da sua casa.
            </p>

            {/* Flyer Notice Pills (Exact styling from the original image) */}
            <div className="flex flex-col sm:flex-row flex-wrap gap-2.5 pt-1">
              <div className="inline-flex items-center gap-2 bg-[#FDE8D4] border border-[#B07C54]/30 px-3.5 py-1.5 rounded-lg text-xs font-bold text-[#381F10] uppercase tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-[#B07C54]" />
                <span>Taxa mínima de entrega: R$ 5,00</span>
              </div>
              <div className="inline-flex items-center gap-2 bg-[#FDE8D4] border border-[#B07C54]/30 px-3.5 py-1.5 rounded-lg text-xs font-bold text-[#381F10] uppercase tracking-wide">
                <Utensils className="w-3.5 h-3.5 text-[#B07C54]" />
                <span>Massas e quibe apenas congelados</span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 text-sm font-bold uppercase tracking-wider text-white bg-[#B07C54] hover:bg-[#8C5B35] active:bg-[#6e4323] rounded-2xl shadow-lg hover:shadow-xl transition-all font-display"
              >
                <MessageCircle className="w-5 h-5 fill-white/20" />
                <span>Pedir no WhatsApp (16) 99719-2160</span>
              </a>

              <a
                href="#cardapio"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-bold uppercase tracking-wider text-[#381F10] bg-white hover:bg-white/90 border-2 border-[#B07C54]/30 rounded-2xl shadow-sm transition-all font-display"
              >
                <span>Ver Preços &amp; Pratos</span>
              </a>
            </div>

            {/* Social channels bar */}
            <div className="flex items-center gap-4 pt-2 text-xs font-bold text-[#381F10]/80">
              <a 
                href={RESTAURANT_INFO.instagramUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-1.5 hover:text-[#B07C54] transition-colors"
              >
                <Instagram className="w-4 h-4 text-[#B07C54]" />
                <span>@RAFA.CONGELADOS</span>
              </a>
              <span>·</span>
              <span>Rua Rio Araguaia, 720</span>
            </div>

          </div>

          {/* Right Column: Interactive Menu Showcase Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group max-w-md w-full">
              
              {/* Outer decorative scallop glow */}
              <div className="absolute -inset-2 bg-[#B07C54] rounded-3xl opacity-20 blur-lg group-hover:opacity-30 transition-opacity" />

              <div className="relative bg-[#FDE8D4] p-6 sm:p-7 rounded-3xl shadow-2xl border-4 border-[#B07C54] space-y-5 text-[#381F10]">
                
                {/* Header of the Card */}
                <div className="flex items-center justify-between pb-4 border-b-2 border-[#B07C54]/25">
                  <div className="flex items-center gap-3">
                    <img
                      src="/assets/logo_rafa.png"
                      alt="Logo RaFa Congelados"
                      className="w-14 h-14 object-contain drop-shadow-sm"
                    />
                    <div>
                      <span className="font-script text-2xl font-bold leading-none block">RaFa</span>
                      <span className="text-[9px] font-bold tracking-[0.2em] bg-[#381F10] text-white px-1.5 py-0.5 rounded-full uppercase">CONGELADOS</span>
                    </div>
                  </div>
                  <span className="font-display text-[11px] font-black uppercase tracking-wider bg-[#A1E4FB] text-[#381F10] px-3 py-1 rounded-full border border-[#B07C54]/30">
                    500g e 1kg
                  </span>
                </div>

                {/* 3 Categories Highlights */}
                <div className="space-y-3 font-display">
                  
                  {/* Tortas */}
                  <div className="p-3.5 bg-white rounded-2xl border-2 border-[#B07C54]/20 shadow-xs flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-[#B07C54] block">TORTAS</span>
                      <p className="text-sm font-bold text-[#381F10]">Frango ou Palmito c/ Catupiry</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-black text-[#381F10] tabular-nums block">a partir de</span>
                      <span className="text-sm font-black text-[#B07C54] tabular-nums">R$ 24,00</span>
                    </div>
                  </div>

                  {/* Massas */}
                  <div className="p-3.5 bg-white rounded-2xl border-2 border-[#B07C54]/20 shadow-xs flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-[#B07C54] block">MASSAS*</span>
                      <p className="text-sm font-bold text-[#381F10]">Nhoque (sem cozimento) &amp; Lasanha</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-black text-[#381F10] tabular-nums block">a partir de</span>
                      <span className="text-sm font-black text-[#B07C54] tabular-nums">R$ 15,00</span>
                    </div>
                  </div>

                  {/* Quibe */}
                  <div className="p-3.5 bg-white rounded-2xl border-2 border-[#B07C54]/20 shadow-xs flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-[#B07C54] block">QUIBE DE FORNO*</span>
                      <p className="text-sm font-bold text-[#381F10]">Recheado c/ Muçarela e Catupiry</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-black text-[#381F10] tabular-nums block">a partir de</span>
                      <span className="text-sm font-black text-[#B07C54] tabular-nums">R$ 22,00</span>
                    </div>
                  </div>

                </div>

                {/* Footer of the Card */}
                <div className="pt-2 flex items-center justify-between text-xs font-bold text-[#381F10]/80 border-t-2 border-[#B07C54]/20">
                  <span className="flex items-center gap-1 text-[11px]">
                    <Sparkles className="w-3.5 h-3.5 text-[#B07C54]" />
                    Taxa mínima: R$ 5,00
                  </span>
                  <a
                    href="#cardapio"
                    className="font-display text-xs font-black uppercase tracking-wider text-[#B07C54] hover:underline"
                  >
                    Ver Cardápio Completo &rarr;
                  </a>
                </div>

              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
