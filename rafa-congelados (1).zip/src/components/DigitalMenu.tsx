import React, { useState } from 'react';
import { MessageCircle, Plus, Check, Sparkles, AlertCircle } from 'lucide-react';
import { MenuItem, PortionSize } from '../types';
import { MENU_ITEMS, RESTAURANT_INFO } from '../data/menu';

interface DigitalMenuProps {
  onAddToCart: (item: MenuItem, portion: PortionSize) => void;
}

export const DigitalMenu: React.FC<DigitalMenuProps> = ({ onAddToCart }) => {
  const [selectedPortions, setSelectedPortions] = useState<Record<string, PortionSize>>({
    'torta-frango-catupiry': '500g',
    'torta-palmito-catupiry': '500g',
    'torta-quatro-queijos-brocolis': '500g',
    'nhoque-batata': '500g',
    'lasanha-bolonhesa': '500g',
    'quibe-recheado': '500g',
  });

  const [addedItemKey, setAddedItemKey] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('todos');

  const categories = [
    { id: 'todos', label: 'Todos os Pratos' },
    { id: 'tortas', label: 'Tortas' },
    { id: 'massas', label: 'Massas*' },
    { id: 'quibe', label: 'Quibe de Forno*' },
  ];

  const handlePortionChange = (itemId: string, portion: PortionSize) => {
    setSelectedPortions((prev) => ({ ...prev, [itemId]: portion }));
  };

  const handleAdd = (item: MenuItem) => {
    const portion = selectedPortions[item.id] || '500g';
    onAddToCart(item, portion);
    const key = `${item.id}-${portion}`;
    setAddedItemKey(key);
    setTimeout(() => {
      setAddedItemKey(null);
    }, 1500);
  };

  const getDirectWhatsAppUrl = (item: MenuItem) => {
    const portion = selectedPortions[item.id] || '500g';
    const price = portion === '500g' ? item.price500g : item.price1kg;
    const message = `Olá, RaFa Congelados! Gostaria de pedir: *${item.name}* no tamanho *${portion}* (R$ ${price.toFixed(2).replace('.', ',')}). Podem me informar a taxa e previsão de entrega?`;
    return `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(message)}`;
  };

  const filteredItems = filterCategory === 'todos'
    ? MENU_ITEMS
    : MENU_ITEMS.filter((item) => item.category === filterCategory);

  // Group by category to reflect the exact flyer structure
  const groupedCategories = [
    {
      id: 'tortas',
      title: 'TORTAS',
      subtitle: 'Massa artesanal amanteigada e recheios super cremosos',
      items: filteredItems.filter((i) => i.category === 'tortas')
    },
    {
      id: 'massas',
      title: 'MASSAS*',
      subtitle: '*Massas apenas congeladas para cozimento/forno prático',
      items: filteredItems.filter((i) => i.category === 'massas')
    },
    {
      id: 'quibe',
      title: 'QUIBE DE FORNO*',
      subtitle: '*Quibe temperado com hortelã fresca, recheado e congelado',
      items: filteredItems.filter((i) => i.category === 'quibe')
    }
  ].filter((group) => group.items.length > 0);

  return (
    <section id="cardapio" className="py-20 md:py-28 bg-[#B07C54] text-white relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 bg-[#A1E4FB] text-[#381F10] px-4 py-1.5 rounded-full font-display text-xs font-black uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Cardápio &amp; Tabela de Preços</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase leading-tight mb-4">
            Escolha seu prato em 500g ou 1kg
          </h2>

          <p className="text-white/85 text-base sm:text-lg">
            Valores oficiais do nosso cardápio impresso. Selecione a porção desejada e envie seu pedido diretamente pelo WhatsApp.
          </p>
        </div>

        {/* Filter Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-12 scrollbar-none">
          {categories.map((cat) => {
            const isActive = filterCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id)}
                type="button"
                className={`px-5 py-2.5 rounded-xl font-display text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-[#A1E4FB] text-[#381F10] shadow-md scale-105'
                    : 'bg-[#8C5B35] text-white/90 hover:bg-[#7a4e2d] hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Grouped Menu Sections matching the flyer */}
        <div className="space-y-16">
          {groupedCategories.map((group) => (
            <div key={group.id} className="space-y-6">
              
              {/* Category Header styled like the flyer blue pill */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b-2 border-white/20 pb-4">
                <div className="inline-block bg-[#A1E4FB] text-[#381F10] px-5 py-2 rounded-2xl font-display font-black text-xl sm:text-2xl uppercase tracking-widest shadow-sm self-start">
                  {group.title}
                </div>
                <p className="text-xs sm:text-sm font-medium text-white/70 italic">
                  {group.subtitle}
                </p>
              </div>

              {/* Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {group.items.map((item) => {
                  const currentPortion = selectedPortions[item.id] || '500g';
                  const currentPrice = currentPortion === '500g' ? item.price500g : item.price1kg;
                  const isItemAdded = addedItemKey === `${item.id}-${currentPortion}`;

                  return (
                    <article
                      key={item.id}
                      className="bg-[#8C5B35]/70 backdrop-blur-xs rounded-2xl p-6 border-2 border-white/15 hover:border-[#A1E4FB] transition-all duration-200 flex flex-col justify-between shadow-md hover:shadow-xl group"
                    >
                      <div>
                        {/* Dish Photograph */}
                        {item.image && item.image !== '/assets/aistudio/image_373ab9b7.png' && (
                          <div className="relative aspect-[16/10] w-full mb-5 overflow-hidden rounded-xl border-2 border-white/20 bg-[#381F10]/40 shadow-xs">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                              loading="lazy"
                            />
                            <div className="absolute top-2.5 left-2.5 bg-[#381F10]/80 backdrop-blur-xs text-[#A1E4FB] text-[10px] font-black uppercase px-2 py-0.5 rounded-md font-display">
                              Foto Real
                            </div>
                          </div>
                        )}

                        {/* Title & Notes */}
                        <div className="mb-4">
                          <h3 className="font-display text-xl font-black text-white uppercase tracking-wide leading-snug">
                            {item.name}
                          </h3>

                          {item.notes && (
                            <p className="text-xs font-bold text-[#A1E4FB] uppercase tracking-wider mt-1 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5" />
                              <span>{item.notes}</span>
                            </p>
                          )}
                        </div>

                        {/* Description */}
                        <p className="text-sm text-white/80 leading-relaxed mb-6 font-normal">
                          {item.shortDescription}
                        </p>

                        {/* Dotted lines pricing as seen on the flyer */}
                        <div className="space-y-2 bg-[#381F10]/30 p-3.5 rounded-xl border border-white/10 mb-6 font-display">
                          <div className={`flex items-baseline justify-between text-sm transition-colors ${currentPortion === '500g' ? 'text-[#A1E4FB] font-bold' : 'text-white/70'}`}>
                            <span className="font-bold">500G</span>
                            <span className="flex-1 mx-2 border-b border-dotted border-white/30" />
                            <span className="font-black tabular-nums">R$ {item.price500g.toFixed(2).replace('.', ',')}</span>
                          </div>

                          <div className={`flex items-baseline justify-between text-sm transition-colors ${currentPortion === '1kg' ? 'text-[#A1E4FB] font-bold' : 'text-white/70'}`}>
                            <span className="font-bold">1KG</span>
                            <span className="flex-1 mx-2 border-b border-dotted border-white/30" />
                            <span className="font-black tabular-nums">R$ {item.price1kg.toFixed(2).replace('.', ',')}</span>
                          </div>
                        </div>

                        {/* Portion Selector Buttons */}
                        <div className="mb-6">
                          <span className="block text-[11px] font-bold text-white/60 uppercase tracking-widest mb-2 font-display">
                            Selecione a porção para pedir:
                          </span>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => handlePortionChange(item.id, '500g')}
                              className={`py-2 px-3 rounded-lg text-xs font-bold font-display uppercase tracking-wider transition-all cursor-pointer ${
                                currentPortion === '500g'
                                  ? 'bg-[#A1E4FB] text-[#381F10] shadow-sm ring-2 ring-white/50'
                                  : 'bg-white/10 text-white hover:bg-white/20'
                              }`}
                            >
                              500G (R$ {item.price500g.toFixed(2).replace('.', ',')})
                            </button>

                            <button
                              type="button"
                              onClick={() => handlePortionChange(item.id, '1kg')}
                              className={`py-2 px-3 rounded-lg text-xs font-bold font-display uppercase tracking-wider transition-all cursor-pointer ${
                                currentPortion === '1kg'
                                  ? 'bg-[#A1E4FB] text-[#381F10] shadow-sm ring-2 ring-white/50'
                                  : 'bg-white/10 text-white hover:bg-white/20'
                              }`}
                            >
                              1KG (R$ {item.price1kg.toFixed(2).replace('.', ',')})
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="pt-4 border-t border-white/10 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleAdd(item)}
                          className="flex-1 inline-flex items-center justify-center gap-1.5 py-3 px-3 text-xs font-bold uppercase tracking-wider font-display rounded-xl bg-white text-[#381F10] hover:bg-[#FDE8D4] transition-all cursor-pointer shadow-xs"
                        >
                          {isItemAdded ? (
                            <>
                              <Check className="w-4 h-4 text-emerald-600" />
                              <span className="text-emerald-700">Adicionado!</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-4 h-4" />
                              <span>Adicionar {currentPortion}</span>
                            </>
                          )}
                        </button>

                        <a
                          href={getDirectWhatsAppUrl(item)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center p-3 rounded-xl bg-[#A1E4FB] text-[#381F10] hover:bg-white transition-all shadow-xs"
                          title={`Pedir ${item.name} (${currentPortion}) no WhatsApp`}
                        >
                          <MessageCircle className="w-4 h-4 fill-[#381F10]" />
                        </a>
                      </div>

                    </article>
                  );
                })}
              </div>

            </div>
          ))}
        </div>

        {/* Delivery Terms Callout as requested on the flyer */}
        <div id="encomendas" className="mt-16 bg-[#FDE8D4] border-2 border-[#381F10] rounded-3xl p-6 sm:p-8 text-[#381F10] flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center md:text-left">
            <span className="font-display font-black text-xs uppercase tracking-widest bg-[#381F10] text-white px-2.5 py-1 rounded-full">
              ENCOMENDAS E ENTREGAS A COMBINAR*
            </span>
            <h4 className="font-display text-xl sm:text-2xl font-black uppercase mt-2">
              Taxa Mínima de Entrega: R$ 5,00
            </h4>
            <p className="text-sm font-medium text-[#381F10]/80">
              *Massas e quibe apenas congelados. Pratos especiais de 4 queijos preparados sob encomenda prévia.
            </p>
          </div>

          <a
            href={`${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
              'Olá! Gostaria de consultar entregas e fazer uma encomenda na RaFa Congelados.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#381F10] hover:bg-[#522e18] text-white font-display text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap shadow-md"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Combinar Entrega no WhatsApp</span>
          </a>
        </div>

      </div>
    </section>
  );
};
