import React, { useState } from 'react';
import { MessageCircle, ShoppingBag, Instagram, Menu as MenuIcon, X, ChefHat } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menu';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Cardápio', href: '#cardapio' },
    { label: 'Encomendas & Taxas', href: '#encomendas' },
    { label: 'Nossa História', href: '#sobre' },
    { label: 'Contato', href: '#contato' },
  ];

  const whatsappUrl = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
    'Olá! Gostaria de fazer um pedido na RaFa Congelados.'
  )}`;

  return (
    <header className="sticky top-0 z-40 w-full bg-[#A1E4FB]/95 backdrop-blur-md border-b-2 border-[#B07C54]/20 transition-all duration-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand wordmark with official logo */}
        <a 
          href="#" 
          className="flex items-center gap-3 group whitespace-nowrap shrink-0"
        >
          <img
            src="/assets/logo_rafa.png"
            alt="RaFa Congelados"
            className="w-13 h-13 object-contain group-hover:scale-105 transition-transform drop-shadow-xs"
          />
          <div className="flex flex-col">
            <span className="font-script text-3xl font-bold leading-none text-[#381F10] tracking-wide">
              RaFa
            </span>
            <span className="text-[9px] font-bold tracking-[0.25em] text-white bg-[#381F10] px-2 py-0.5 rounded-full uppercase text-center mt-0.5">
              CONGELADOS
            </span>
          </div>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-bold tracking-wide text-[#381F10]">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="hover:text-[#B07C54] transition-colors whitespace-nowrap shrink-0 py-1 font-display"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Actions (Cart + Instagram + WhatsApp) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <a
            href={RESTAURANT_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2.5 text-[#381F10] hover:text-[#B07C54] hover:bg-white/40 rounded-xl transition-colors hidden sm:flex items-center justify-center"
            title="Siga @rafa.congelados no Instagram"
            aria-label="Instagram @rafa.congelados"
          >
            <Instagram className="w-5 h-5" />
          </a>

          <button
            onClick={onOpenCart}
            type="button"
            className="relative p-2.5 text-[#381F10] hover:bg-white/40 rounded-xl transition-colors cursor-pointer"
            title="Ver sacola de pedidos"
            aria-label="Ver sacola de pedidos"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-5 h-5 px-1 text-xs font-black text-white bg-[#B07C54] rounded-full tabular-nums shadow-sm border border-white">
                {cartCount}
              </span>
            )}
          </button>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-[#B07C54] hover:bg-[#8C5B35] active:bg-[#6e4323] rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0 font-display"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>(16) 99719-2160</span>
          </a>

          {/* Mobile menu button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#381F10] hover:bg-white/30 rounded-lg"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#B07C54]/20 bg-[#A1E4FB] px-6 py-6 shadow-xl space-y-4">
          <div className="flex flex-col space-y-3 font-display">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-bold text-[#381F10] hover:text-[#B07C54] py-1 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href={RESTAURANT_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm font-bold text-[#381F10] hover:text-[#B07C54] py-1"
            >
              <Instagram className="w-4 h-4" />
              <span>@RAFA.CONGELADOS</span>
            </a>
          </div>

          <div className="pt-3 border-t border-[#B07C54]/20">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-bold uppercase tracking-wider text-white bg-[#B07C54] hover:bg-[#8C5B35] rounded-xl shadow-sm transition-colors font-display"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Pedir no WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
