import React from 'react';
import { X, Plus, Minus, Trash2, MessageCircle, ShoppingBag, AlertCircle } from 'lucide-react';
import { CartItem, PortionSize } from '../types';
import { RESTAURANT_INFO } from '../data/menu';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, portion: PortionSize, delta: number) => void;
  onRemoveItem: (itemId: string, portion: PortionSize) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  if (!isOpen) return null;

  const total = items.reduce((acc, curr) => {
    const unitPrice = curr.portion === '500g' ? curr.item.price500g : curr.item.price1kg;
    return acc + unitPrice * curr.quantity;
  }, 0);

  const handleCheckoutWhatsApp = () => {
    if (items.length === 0) return;

    let message = `Olá, RaFa Congelados! Gostaria de fazer o seguinte pedido do cardápio:\n\n`;
    items.forEach((ci) => {
      const unitPrice = ci.portion === '500g' ? ci.item.price500g : ci.item.price1kg;
      const sub = unitPrice * ci.quantity;
      message += `• *${ci.quantity}x ${ci.item.name} (${ci.portion})* — R$ ${sub.toFixed(2).replace('.', ',')}\n`;
    });
    message += `\n*Subtotal dos Pratos:* R$ ${total.toFixed(2).replace('.', ',')}\n`;
    message += `*Taxa Mínima de Entrega:* R$ ${RESTAURANT_INFO.minDeliveryFee}\n\n`;
    message += `Gostaria de combinar a entrega / retirada e o pagamento.`;

    const url = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-[#381F10]/60 backdrop-blur-xs transition-opacity" 
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l-4 border-[#B07C54]">
          
          {/* Header */}
          <div className="p-6 bg-[#A1E4FB] border-b-2 border-[#B07C54]/30 flex items-center justify-between text-[#381F10]">
            <div className="flex items-center gap-3">
              <img
                src="/assets/logo_rafa.png"
                alt="Logo"
                className="w-10 h-10 object-contain drop-shadow-xs"
              />
              <div>
                <h3 className="font-display text-lg font-black uppercase tracking-wide">
                  Sua Sacola
                </h3>
                <p className="text-xs font-semibold text-[#381F10]/70">
                  {items.length === 0 ? 'Vazia no momento' : `${items.length} ${items.length === 1 ? 'item' : 'itens'}`}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              type="button"
              className="p-2 text-[#381F10] hover:bg-white/40 rounded-xl transition-colors cursor-pointer"
              aria-label="Fechar sacola"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items List */}
          <div className="p-6 overflow-y-auto flex-1 space-y-4">
            {items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#FDE8D4] border-2 border-[#B07C54] flex items-center justify-center mx-auto text-[#381F10]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="font-display text-lg font-black uppercase text-[#381F10]">
                  Sua sacola está vazia
                </p>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Escolha tortas, massas ou quibe de forno no tamanho de 500g ou 1kg e adicione aqui.
                </p>
                <button
                  onClick={onClose}
                  type="button"
                  className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl bg-[#B07C54] text-white font-display text-xs font-bold uppercase tracking-wider hover:bg-[#8C5B35] transition-colors cursor-pointer"
                >
                  Ver Cardápio
                </button>
              </div>
            ) : (
              items.map(({ item, portion, quantity }) => {
                const unitPrice = portion === '500g' ? item.price500g : item.price1kg;
                const sub = unitPrice * quantity;

                return (
                  <div
                    key={`${item.id}-${portion}`}
                    className="p-4 bg-[#FDE8D4]/40 rounded-2xl border-2 border-[#B07C54]/25 flex items-center justify-between gap-3"
                  >
                    {item.image && item.image !== '/assets/aistudio/image_373ab9b7.png' && (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-14 h-14 rounded-xl object-cover shrink-0 border border-[#B07C54]/30"
                      />
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-display text-xs font-black px-2 py-0.5 rounded-md bg-[#A1E4FB] text-[#381F10] uppercase">
                          {portion}
                        </span>
                        <h4 className="font-display text-sm font-bold text-[#381F10] truncate">
                          {item.name}
                        </h4>
                      </div>

                      <p className="text-xs text-slate-500 mt-1">
                        R$ {unitPrice.toFixed(2).replace('.', ',')} un.
                      </p>

                      {/* Quantity controls */}
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => onUpdateQuantity(item.id, portion, -1)}
                          type="button"
                          className="w-6 h-6 rounded-md bg-white border border-[#B07C54]/40 text-[#381F10] flex items-center justify-center hover:bg-slate-100 cursor-pointer"
                          aria-label="Diminuir quantidade"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-black font-display text-[#381F10] tabular-nums px-1">
                          {quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, portion, 1)}
                          type="button"
                          className="w-6 h-6 rounded-md bg-white border border-[#B07C54]/40 text-[#381F10] flex items-center justify-center hover:bg-slate-100 cursor-pointer"
                          aria-label="Aumentar quantidade"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="font-display text-sm font-black text-[#381F10] tabular-nums mb-1">
                        R$ {sub.toFixed(2).replace('.', ',')}
                      </p>
                      <button
                        onClick={() => onRemoveItem(item.id, portion)}
                        type="button"
                        className="text-slate-400 hover:text-rose-500 transition-colors p-1 cursor-pointer"
                        title="Remover"
                        aria-label="Remover item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Checkout */}
          {items.length > 0 && (
            <div className="p-6 border-t-2 border-[#B07C54]/30 bg-[#FDE8D4] text-[#381F10] space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold text-slate-700">Subtotal</span>
                  <span className="font-display font-black text-xl tabular-nums">
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <AlertCircle className="w-3.5 h-3.5 text-[#B07C54]" />
                  <span>Taxa mínima de entrega: R$ 5,00 (a combinar)</span>
                </div>
              </div>

              <button
                onClick={handleCheckoutWhatsApp}
                type="button"
                className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-[#B07C54] hover:bg-[#8C5B35] text-white font-display text-sm font-bold uppercase tracking-wider transition-all shadow-md cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-white/20" />
                <span>Pedir no WhatsApp</span>
              </button>

              <button
                onClick={onClearCart}
                type="button"
                className="w-full text-center text-xs text-slate-500 hover:text-slate-800 py-1 transition-colors cursor-pointer"
              >
                Limpar sacola
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
