import React from 'react';
import { Award, Heart, Users, Flame, MessageCircle, Sparkles } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menu';

export const About: React.FC = () => {
  const pillars = [
    {
      icon: Users,
      title: 'Ra & Fa',
      description: 'Mãe e filha unidas pelo amor à mesa farta, transformando tradição familiar em cuidado em cada entrega.'
    },
    {
      icon: Award,
      title: 'Receitas da Vó Ana',
      description: 'Tesouros culinários passados de geração em geração e aperfeiçoados com rigor e carinho.'
    },
    {
      icon: Flame,
      title: 'Desde 2020',
      description: 'O que começou como uma fornada de torta de frango em casa conquistou vizinhos e amigos em minutos.'
    },
    {
      icon: Heart,
      title: 'Comida de Mãe',
      description: 'Sabor verdadeiro, ingredientes selecionados e preparo artesanal para o cotidiano do seu lar.'
    }
  ];

  const whatsappUrl = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
    'Olá, Fabiana e Rafaela! Conheci a história da RaFa Congelados e gostaria de fazer um pedido.'
  )}`;

  return (
    <section id="sobre" className="py-20 md:py-28 bg-[#A1E4FB]/20 border-t-4 border-[#B07C54] overflow-hidden text-[#381F10]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Tag */}
        <div className="inline-flex items-center gap-2 bg-[#FDE8D4] border border-[#B07C54] px-4 py-1.5 rounded-full font-display text-xs font-black uppercase tracking-widest mb-4">
          <Sparkles className="w-3.5 h-3.5 text-[#B07C54]" />
          <span>HISTÓRIA DAS DONAS · MÃE &amp; FILHA</span>
        </div>

        {/* Section Grid: Story left + Owners Photo right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-16">
          
          {/* Left Text Column */}
          <div className="lg:col-span-6 space-y-5">
            <h2 className="text-3xl sm:text-5xl font-black font-display uppercase tracking-tight leading-tight">
              Duas gerações unidas pelo amor à mesa farta
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-slate-700 leading-relaxed font-normal">
              <p className="text-base sm:text-lg font-semibold text-[#381F10]">
                O nome <span className="text-[#8C5B35] font-bold">RaFa</span> nasceu da união de duas gerações: <strong>Ra</strong> de Rafaela e <strong>Fa</strong> de Fabiana, mãe e filha unidas pelo amor à mesa farta.
              </p>

              <p>
                Tudo começou no meio da pandemia em 2020. Com a família reunida em casa, Fabiana passou a cozinhar ainda mais, resgatando receitas queridas que já preparava para vender na época em que Rafaela nasceu. Entre esses tesouros culinários estavam receitas tradicionais criadas pela saudosa Vó Ana, sogra de Fabiana e avó de Rafaela.
              </p>

              <p>
                Certo dia, assaram algumas fornadas de torta de frango com Catupiry para consumo da própria casa. Ao compartilharem fotos nas redes, os amigos e vizinhos começaram a perguntar se estavam à venda. Naquele dia ainda não eram, mas a resposta não demorou: no dia seguinte, prepararam novas fornadas, anunciaram e venderam absolutamente tudo em minutos.
              </p>

              <p>
                De fornada em fornada, a produção foi crescendo de forma acolhedora. As antigas receitas de família foram aperfeiçoadas com cuidado e rigor, dando vida à <strong>RaFa Congelados &amp; Artesanais</strong>: um negócio familiar dedicado a levar o verdadeiro sabor da comida de mãe para o cotidiano do seu lar.
              </p>
            </div>

            <div className="pt-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-[#B07C54] hover:bg-[#8C5B35] text-white font-display text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Falar com Fabiana e Rafaela</span>
              </a>
            </div>
          </div>

          {/* Right Image Column: Photo of Owners (Fabiana & Rafaela) */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-[#B07C54] bg-[#FDE8D4]">
              <img
                src="/assets/aistudio/image_b187f94f.png"
                alt="Fabiana e Rafaela, mãe e filha fundadoras da RaFa Congelados & Artesanais, preparando nhoque artesanal na cozinha"
                className="w-full h-auto max-h-[600px] object-cover object-top hover:scale-[1.02] transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
                loading="lazy"
              />

              <div className="bg-white/95 backdrop-blur-md p-4 sm:p-5 border-t-2 border-[#B07C54]/30">
                <p className="text-xs sm:text-sm font-display italic font-semibold text-[#381F10]">
                  "Levando o verdadeiro sabor da comida de mãe e as receitas da Vó Ana para o cotidiano do seu lar."
                </p>
                <p className="text-[11px] font-bold font-display uppercase tracking-wider text-[#B07C54] mt-1">
                  — Fabiana &amp; Rafaela · RaFa Congelados &amp; Artesanais
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* 4 Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-8 border-t-2 border-[#B07C54]/20">
          {pillars.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <div 
                key={pillar.title}
                className="p-6 bg-white rounded-3xl border-2 border-[#B07C54]/20 shadow-xs hover:border-[#B07C54] hover:shadow-md transition-all duration-200"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#FDE8D4] text-[#B07C54] flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-display text-lg font-black uppercase text-[#381F10] mb-2">
                  {pillar.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                  {pillar.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
