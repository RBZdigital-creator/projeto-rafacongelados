import React, { useState } from 'react';
import { MapPin, Phone, MessageCircle, Instagram, Send, Navigation, Sparkles } from 'lucide-react';
import { RESTAURANT_INFO, MENU_ITEMS } from '../data/menu';
import { PortionSize } from '../types';

export const Contact: React.FC = () => {
  const [customerName, setCustomerName] = useState('');
  const [selectedDish, setSelectedDish] = useState('');
  const [selectedPortion, setSelectedPortion] = useState<PortionSize>('500g');
  const [deliveryAddress, setDeliveryAddress] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    let text = `Olá, RaFa Congelados! Meu nome é ${customerName || 'Cliente'}.\n`;
    if (selectedDish) {
      text += `Gostaria de pedir: *${selectedDish}* (${selectedPortion}).\n`;
    } else {
      text += `Gostaria de consultar as opções de congelados disponíveis para hoje.\n`;
    }
    if (deliveryAddress) {
      text += `Endereço para entrega / retirada: ${deliveryAddress}.\n`;
    }
    text += `Podem me confirmar o valor total com a taxa de entrega?`;

    const url = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${RESTAURANT_INFO.address}, ${RESTAURANT_INFO.city}`
  )}`;

  return (
    <section id="contato" className="py-20 md:py-28 bg-white border-t-4 border-[#B07C54]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 bg-[#FDE8D4] border border-[#B07C54] px-4 py-1.5 rounded-full font-display text-xs font-black uppercase tracking-widest text-[#381F10] mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#B07C54]" />
            <span>CONTATOS OFICIAIS</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black font-display text-[#381F10] tracking-tight uppercase leading-tight mb-4">
            Peça no WhatsApp ou venha retirar
          </h2>

          <p className="text-base sm:text-lg text-slate-600 font-medium">
            Entregas em domicílio (taxa mínima de R$ 5,00) ou retirada rápida no nosso endereço no bairro.
          </p>
        </div>

        {/* 2-Column Split: Info Cards Left + Direct WhatsApp Form Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Contact Cards styled with flyer colors */}
          <div className="lg:col-span-5 space-y-5">
            
            {/* WhatsApp Card */}
            <div className="p-6 bg-[#A1E4FB]/40 rounded-3xl border-2 border-[#B07C54]/30 shadow-xs">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#B07C54] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display text-xs font-bold uppercase tracking-wider text-[#381F10]/70 mb-1">
                    WhatsApp &amp; Telefone
                  </h3>
                  <p className="font-display text-2xl font-black text-[#381F10] mb-2">
                    {RESTAURANT_INFO.phoneDisplay}
                  </p>
                  <p className="text-xs text-slate-600 mb-4">
                    Atendimento atencioso direto da cozinha para seus pedidos.
                  </p>
                  <a
                    href={`${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
                      'Olá! Gostaria de fazer meu pedido na RaFa Congelados.'
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#B07C54] hover:bg-[#8C5B35] text-white font-display text-xs font-bold uppercase tracking-wider transition-colors shadow-xs"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Iniciar Conversa</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Instagram Card */}
            <div className="p-6 bg-[#FDE8D4] rounded-3xl border-2 border-[#B07C54]/30 shadow-xs">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[#381F10] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Instagram className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display text-xs font-bold uppercase tracking-wider text-[#381F10]/70 mb-1">
                    Instagram Oficial
                  </h3>
                  <p className="font-display text-xl font-black text-[#381F10] mb-2">
                    {RESTAURANT_INFO.instagram}
                  </p>
                  <p className="text-xs text-slate-600 mb-4">
                    Fotos dos pratos quentinhos saindo do forno e novidades semanais.
                  </p>
                  <a
                    href={RESTAURANT_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-[#381F10] border border-[#B07C54]/30 font-display text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    <Instagram className="w-3.5 h-3.5 text-[#B07C54]" />
                    <span>Seguir no Instagram</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Address Card */}
            <div className="p-6 bg-neutral-50 rounded-3xl border-2 border-slate-200 shadow-xs">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Endereço
                  </h3>
                  <p className="font-display text-lg font-black text-[#381F10] mb-1">
                    {RESTAURANT_INFO.address}
                  </p>
                  <p className="text-xs text-slate-600 mb-3">
                    {RESTAURANT_INFO.city} · Retiradas com aviso prévio pelo WhatsApp.
                  </p>
                  <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#B07C54] hover:underline"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Abrir no Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

          </div>

          {/* Right: Interactive WhatsApp Message Builder */}
          <div className="lg:col-span-7 bg-[#A1E4FB]/25 p-8 sm:p-10 rounded-3xl border-2 border-[#B07C54]/40 shadow-sm">
            <div className="mb-6">
              <span className="font-display text-xs font-black uppercase tracking-widest text-[#B07C54] bg-white px-3 py-1 rounded-full border border-[#B07C54]/30">
                Agilize seu Pedido
              </span>
              <h3 className="text-2xl sm:text-3xl font-black font-display uppercase text-[#381F10] mt-3 mb-2">
                Monte sua Mensagem Pronta
              </h3>
              <p className="text-sm text-slate-600">
                Preencha os dados abaixo e clique para abrir a conversa no WhatsApp já com o prato e porção escolhidos.
              </p>
            </div>

            <form onSubmit={handleSendMessage} className="space-y-4">
              <div>
                <label htmlFor="input-name" className="block text-xs font-bold font-display uppercase tracking-wider text-[#381F10] mb-1.5">
                  Seu Nome
                </label>
                <input
                  id="input-name"
                  type="text"
                  placeholder="Ex.: Mariana Souza"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-4 py-3 bg-white border-2 border-[#B07C54]/30 rounded-xl text-[#381F10] placeholder:text-slate-400 focus:border-[#B07C54] focus:ring-0 transition-colors text-sm font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label htmlFor="select-dish" className="block text-xs font-bold font-display uppercase tracking-wider text-[#381F10] mb-1.5">
                    Escolha o Prato
                  </label>
                  <select
                    id="select-dish"
                    value={selectedDish}
                    onChange={(e) => setSelectedDish(e.target.value)}
                    className="w-full px-4 py-3 bg-white border-2 border-[#B07C54]/30 rounded-xl text-[#381F10] focus:border-[#B07C54] focus:ring-0 transition-colors text-sm font-medium cursor-pointer"
                  >
                    <option value="">Selecione um prato...</option>
                    {MENU_ITEMS.map((item) => (
                      <option key={item.id} value={item.name}>
                        {item.name}
                      </option>
                    ))}
                    <option value="Quero consultar o cardápio do dia">Outro prato ou dúvida geral</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="select-portion" className="block text-xs font-bold font-display uppercase tracking-wider text-[#381F10] mb-1.5">
                    Porção
                  </label>
                  <select
                    id="select-portion"
                    value={selectedPortion}
                    onChange={(e) => setSelectedPortion(e.target.value as PortionSize)}
                    className="w-full px-4 py-3 bg-white border-2 border-[#B07C54]/30 rounded-xl text-[#381F10] focus:border-[#B07C54] focus:ring-0 transition-colors text-sm font-medium cursor-pointer"
                  >
                    <option value="500g">500G</option>
                    <option value="1kg">1KG</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="input-address" className="block text-xs font-bold font-display uppercase tracking-wider text-[#381F10] mb-1.5">
                  Endereço de Entrega ou Retirada
                </label>
                <input
                  id="input-address"
                  type="text"
                  placeholder="Ex.: Rua das Flores, 120 - Bairro Centro"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full px-4 py-3 bg-white border-2 border-[#B07C54]/30 rounded-xl text-[#381F10] placeholder:text-slate-400 focus:border-[#B07C54] focus:ring-0 transition-colors text-sm font-medium"
                />
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-[#B07C54] hover:bg-[#8C5B35] text-white font-display text-sm font-bold uppercase tracking-wider transition-all shadow-md cursor-pointer mt-2"
              >
                <Send className="w-4 h-4" />
                <span>Enviar Pedido para o WhatsApp</span>
              </button>

              <div className="pt-2 text-center text-xs text-slate-500 font-medium">
                *Taxa mínima de entrega: R$ 5,00 · Massas e quibe apenas congelados.
              </div>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
