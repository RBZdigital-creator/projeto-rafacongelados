import React from 'react';
import { ChefHat, MessageCircle, Instagram, ArrowUp, Heart } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/menu';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappUrl = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
    'Olá! Vim pelo site da RaFa Congelados.'
  )}`;

  return (
    <footer className="bg-[#381F10] text-[#FDE8D4] py-16 border-t-4 border-[#B07C54]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top footer row */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-white/10">
          
          {/* Brand lockup */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <img
                src="/assets/logo_rafa.png"
                alt="RaFa Congelados"
                className="w-14 h-14 object-contain drop-shadow-sm"
              />
              <div className="flex flex-col">
                <span className="font-script text-4xl font-bold leading-none text-[#FDE8D4]">
                  RaFa
                </span>
                <span className="text-[10px] font-bold tracking-[0.25em] text-[#381F10] bg-[#A1E4FB] px-2 py-0.5 rounded-full uppercase text-center mt-1">
                  CONGELADOS
                </span>
              </div>
            </div>

            <p className="text-xs text-[#FDE8D4]/70 max-w-sm">
              Tortas amanteigadas, massas artesanais e quibe de forno. O carinho e sabor de casa no seu freezer.
            </p>
          </div>

          {/* Quick Links */}
          <div className="flex flex-wrap items-center gap-6 font-display text-xs font-bold uppercase tracking-wider text-[#FDE8D4]/90">
            <a href="#cardapio" className="hover:text-[#A1E4FB] transition-colors">Cardápio &amp; Preços</a>
            <a href="#encomendas" className="hover:text-[#A1E4FB] transition-colors">Taxas &amp; Encomendas</a>
            <a href="#sobre" className="hover:text-[#A1E4FB] transition-colors">Nossa História</a>
            <a href="#contato" className="hover:text-[#A1E4FB] transition-colors">Contatos</a>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <a
              href={RESTAURANT_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-white/10 hover:bg-white/20 text-[#FDE8D4] transition-colors"
              title="Instagram @rafa.congelados"
            >
              <Instagram className="w-5 h-5" />
            </a>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#B07C54] hover:bg-[#8C5B35] text-white font-display text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>(16) 99719-2160</span>
            </a>
          </div>

        </div>

        {/* Bottom row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#FDE8D4]/60">
          <div className="flex flex-wrap items-center gap-2">
            <span>{RESTAURANT_INFO.address} · {RESTAURANT_INFO.city}</span>
            <span>·</span>
            <span>Taxa mínima de entrega: R$ {RESTAURANT_INFO.minDeliveryFee}</span>
          </div>

          <div className="flex items-center gap-4">
            <p className="flex items-center gap-1 font-display">
              Feito com carinho <Heart className="w-3.5 h-3.5 text-[#A1E4FB] fill-[#A1E4FB]" /> RaFa Congelados
            </p>

            <button
              onClick={scrollToTop}
              type="button"
              className="p-2 bg-white/10 hover:bg-white/20 text-[#FDE8D4] rounded-lg transition-colors cursor-pointer"
              title="Voltar ao topo"
              aria-label="Voltar ao topo"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Creator contact email */}
        <div className="pt-4 mt-4 border-t border-white/10 text-center text-[11px] text-[#FDE8D4]/50">
          Site desenvolvido por{' '}
          <a
            href="mailto:contatorbzdigital2023@gmail.com"
            className="text-[#A1E4FB]/80 hover:text-[#A1E4FB] underline underline-offset-2 transition-colors"
          >
            contatorbzdigital2023@gmail.com
          </a>
        </div>

      </div>
    </footer>
  );
};
