import { MenuItem } from '../types';

export const MENU_ITEMS: MenuItem[] = [
  // --- TORTAS ---
  {
    id: 'torta-frango-catupiry',
    name: 'Frango c/ Catupiry',
    category: 'tortas',
    categoryLabel: 'Torta Salgada',
    shortDescription: 'Frango desfiado suculento, tempero especial de casa e legítimo Catupiry cremoso com massa amanteigada.',
    price500g: 24.0,
    price1kg: 45.0,
    image: '/assets/aistudio/image_eafdf1b3.png'
  },
  {
    id: 'torta-palmito-catupiry',
    name: 'Palmito c/ Catupiry',
    category: 'tortas',
    categoryLabel: 'Torta Salgada',
    shortDescription: 'Palmito macio em pedaços nobres, refogado suavemente com ervas finas e coberto com Catupiry.',
    price500g: 26.0,
    price1kg: 48.0,
    image: '/assets/aistudio/image_fde3a092.png'
  },
  {
    id: 'torta-quatro-queijos-brocolis',
    name: 'Quatro Queijos c/ Brócolis',
    category: 'tortas',
    categoryLabel: 'Torta Salgada',
    shortDescription: 'Combinação equilibrada de quatro queijos nobres derretidos com brócolis frescos refogados no alho.',
    price500g: 28.0,
    price1kg: 50.0,
    notes: 'Apenas sob encomenda',
    isOnlyOrder: true,
    image: '/assets/aistudio/image_9af833a1.png'
  },

  // --- MASSAS ---
  {
    id: 'nhoque-batata',
    name: 'Nhoque de Batata',
    category: 'massas',
    categoryLabel: 'Massa Artesanal',
    shortDescription: 'Nhoque artesanal leve como nuvem. Praticidade absoluta: dispensa cozimento na água, vai direto ao forno.',
    price500g: 15.0,
    price1kg: 25.0,
    notes: 'Dispensa cozimento · Apenas congelado',
    noBoilRequired: true,
    isOnlyFrozen: true,
    image: '/assets/aistudio/image_8358c71d.png'
  },
  {
    id: 'lasanha-bolonhesa',
    name: 'Lasanha à Bolonhesa',
    category: 'massas',
    categoryLabel: 'Massa Artesanal',
    shortDescription: 'Camadas generosas de massa caseira, molho à bolonhesa com carne selecionada, queijo muçarela e gratinado.',
    price500g: 22.0,
    price1kg: 40.0,
    notes: 'Apenas congelado',
    isOnlyFrozen: true,
    image: '/assets/aistudio/image_df713e0e.png'
  },

  // --- QUIBE DE FORNO ---
  {
    id: 'quibe-recheado',
    name: 'Quibe Recheado (Muçarela e Catupiry)',
    category: 'quibe',
    categoryLabel: 'Quibe de Forno',
    shortDescription: 'Trigo para quibe temperado com hortelã fresca e especiarias, com recheio duplo de muçarela e Catupiry.',
    price500g: 22.0,
    price1kg: 40.0,
    notes: 'Apenas congelado',
    isOnlyFrozen: true,
    image: '/assets/aistudio/image_a47616a4.png'
  }
];

export const RESTAURANT_INFO = {
  name: 'RaFa Congelados',
  slogan: 'Praticidade e sabor caseiro no seu dia a dia.',
  headlineShort: 'Sabor de verdade, pronto para aquecer.',
  phoneDisplay: '(16) 99719-2160',
  phoneRaw: '5516997192160',
  instagram: '@RAFA.CONGELADOS',
  instagramUrl: 'https://instagram.com/rafa.congelados',
  address: 'Rua Rio Araguaia, 720',
  city: 'Ribeirão Preto - SP',
  minDeliveryFee: '5,00',
  deliveryNotes: 'Encomendas e entregas a combinar · Taxa mínima de R$ 5,00',
  whatsappBaseUrl: 'https://wa.me/5516997192160',
  logoUrl: '/assets/logo_rafa.png'
};
