/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MessageCircle, ShoppingBag } from 'lucide-react';
import { MenuItem, CartItem, PortionSize } from './types';
import { RESTAURANT_INFO } from './data/menu';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { DigitalMenu } from './components/DigitalMenu';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const totalCartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  const handleAddToCart = (item: MenuItem, portion: PortionSize) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (ci) => ci.item.id === item.id && ci.portion === portion
      );
      if (existingIndex > -1) {
        return prev.map((ci, index) =>
          index === existingIndex ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [...prev, { item, portion, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (itemId: string, portion: PortionSize, delta: number) => {
    setCart((prev) => {
      return prev
        .map((ci) => {
          if (ci.item.id === itemId && ci.portion === portion) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter((ci): ci is CartItem => ci !== null);
    });
  };

  const handleRemoveItem = (itemId: string, portion: PortionSize) => {
    setCart((prev) =>
      prev.filter((ci) => !(ci.item.id === itemId && ci.portion === portion))
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const floatingWhatsAppUrl = `${RESTAURANT_INFO.whatsappBaseUrl}?text=${encodeURIComponent(
    'Olá! Estava navegando no site da RaFa Congelados e gostaria de fazer meu pedido.'
  )}`;

  return (
    <div className="min-h-screen flex flex-col bg-[#A1E4FB] text-[#381F10] antialiased selection:bg-[#FDE8D4] selection:text-[#381F10]">
      {/* Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero with Flyer branding & logo seal */}
        <Hero />

        {/* 2. Interactive Digital Menu (Tortas, Massas*, Quibe*) with 500g and 1kg */}
        <DigitalMenu onAddToCart={handleAddToCart} />

        {/* 3. Sobre a Cozinha e Tradição (Replaced redundant flyer image section) */}
        <About />

        {/* 4. Contact, Address, Delivery terms & WhatsApp message builder */}
        <Contact />
      </main>

      {/* 5. Footer */}
      <Footer />

      {/* Slide-over Cart / WhatsApp Order Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Floating Action Controls */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-3 pointer-events-auto">
        {totalCartCount > 0 && (
          <button
            onClick={() => setIsCartOpen(true)}
            type="button"
            className="flex items-center gap-2 px-4 py-2.5 bg-white text-[#381F10] rounded-full shadow-lg border-2 border-[#B07C54] hover:bg-[#FDE8D4] transition-all transform hover:scale-105 cursor-pointer font-display text-xs font-bold"
            aria-label="Abrir sacola de compras"
          >
            <ShoppingBag className="w-4 h-4 text-[#B07C54]" />
            <span className="tabular-nums">
              {totalCartCount} {totalCartCount === 1 ? 'item' : 'itens'} na sacola
            </span>
          </button>
        )}

        <a
          href={floatingWhatsAppUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-3 bg-[#B07C54] hover:bg-[#8C5B35] active:bg-[#6e4323] text-white p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border-2 border-white/40"
          title="Fale conosco no WhatsApp"
          aria-label="Fale conosco no WhatsApp"
        >
          <MessageCircle className="w-6 h-6 fill-white/20" />
          <span className="hidden sm:inline font-display font-bold text-xs uppercase tracking-wider">
            Pedir no WhatsApp
          </span>
        </a>
      </div>
    </div>
  );
}
